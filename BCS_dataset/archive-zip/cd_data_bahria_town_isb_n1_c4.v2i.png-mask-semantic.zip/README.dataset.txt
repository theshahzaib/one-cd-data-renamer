# cd_data_bahria_town_isb_n1_c4 > 2024-01-30 11:04am
https://universe.roboflow.com/zaibi-rnd/cd_data_bahria_town_isb_n1_c4

Provided by a Roboflow user
License: MIT

