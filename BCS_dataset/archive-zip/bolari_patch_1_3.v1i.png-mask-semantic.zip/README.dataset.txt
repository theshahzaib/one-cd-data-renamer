# bolari_patch_1_3 > 2024-03-13 9:55am
https://universe.roboflow.com/zaibi-rnd/bolari_patch_1_3

Provided by a Roboflow user
License: CC BY 4.0

