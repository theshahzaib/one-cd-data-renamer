# park_view_patch_3_3_p10_c4 > 2024-03-01 12:23pm
https://universe.roboflow.com/zaibi-rnd/park_view_patch_3_3_p10_c4

Provided by a Roboflow user
License: CC BY 4.0

