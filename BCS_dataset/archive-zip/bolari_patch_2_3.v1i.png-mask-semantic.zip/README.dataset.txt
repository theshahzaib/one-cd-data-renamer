# bolari_patch_2_3 > 2024-03-13 10:23am
https://universe.roboflow.com/zaibi-rnd/bolari_patch_2_3

Provided by a Roboflow user
License: CC BY 4.0

