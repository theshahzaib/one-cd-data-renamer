# park_view_patch_3_1_p8_c4 > 2024-02-27 12:28pm
https://universe.roboflow.com/zaibi-rnd/park_view_patch_3_1_p8_c4

Provided by a Roboflow user
License: CC BY 4.0

