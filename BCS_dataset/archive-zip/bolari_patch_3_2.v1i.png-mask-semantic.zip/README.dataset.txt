# bolari_patch_3_2 > 2024-03-14 10:40am
https://universe.roboflow.com/zaibi-rnd/bolari_patch_3_2

Provided by a Roboflow user
License: CC BY 4.0

