# bolari_patch_2_2 > 2024-03-13 10:11am
https://universe.roboflow.com/zaibi-rnd/bolari_patch_2_2

Provided by a Roboflow user
License: CC BY 4.0

