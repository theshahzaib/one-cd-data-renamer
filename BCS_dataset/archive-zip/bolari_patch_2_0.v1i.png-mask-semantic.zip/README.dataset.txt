# bolari_patch_2_0 > 2024-03-13 10:03am
https://universe.roboflow.com/zaibi-rnd/bolari_patch_2_0

Provided by a Roboflow user
License: CC BY 4.0

