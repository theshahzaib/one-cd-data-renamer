# bolari_patch_1_1 > 2024-03-13 9:53am
https://universe.roboflow.com/zaibi-rnd/bolari_patch_1_1

Provided by a Roboflow user
License: CC BY 4.0

