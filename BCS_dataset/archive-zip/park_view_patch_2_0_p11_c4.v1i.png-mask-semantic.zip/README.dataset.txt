# park_view_patch_2_0_p11_c4 > 2024-03-06 3:21pm
https://universe.roboflow.com/zaibi-rnd/park_view_patch_2_0_p11_c4

Provided by a Roboflow user
License: CC BY 4.0

